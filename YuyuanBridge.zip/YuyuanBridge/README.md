# 芋圆机助手（YuyuanBridge）· 地基版 v0.1

这是给芋圆机做"跑腿"的**原生 iOS 小 App**。它本身几乎没界面，作用是：
接住芋圆机网页甩来的 `yuyuanji://` 链接 → 去调 Apple 的接口 → **写进真·提醒事项 / 弹真·本地通知**。

> 芋圆机（酒馆里的网页脚本）**不变**。这个小 App 是它旁边多出来的一只"手"。

这一版是**地基**，只做两件事：**写提醒 + 弹通知**。目标是先跑通
「云编译出 .ipa → 你自签装上 → 点个链接就真弹通知/写提醒」这条链路。
通了之后，再往里加日历 / Siri / App Intents。

---

## 一、先把这条链路跑通（你只有 Windows + iPad 也能做）

### 步骤 1：建 GitHub 仓库
1. 注册/登录 github.com，新建一个仓库（Public 即可），比如 `YuyuanBridge`。
2. 把本文件夹里的所有文件**保持目录结构**上传上去，最终仓库里应是：
   ```
   project.yml
   README.md
   Sources/YuyuanBridgeApp.swift
   Sources/ContentView.swift
   Sources/ActionHandler.swift
   Sources/Info.plist
   .github/workflows/build.yml
   ```
   （`.github` 这个带点的文件夹别漏，网页上传可以先建 `.github/workflows/` 再传 build.yml。）

### 步骤 2：云编译（不用 Mac）
1. 上传后进仓库的 **Actions** 标签页 → 找到 "Build unsigned IPA" → 点 **Run workflow**（或每次推送自动跑）。
2. 等 3–6 分钟，绿勾出现后点进这次运行，页面底部 **Artifacts** 里下载
   `YuyuanBridge-unsigned-ipa`（是个 zip，解压出 `YuyuanBridge-unsigned.ipa`）。
   - 这个 .ipa 是**未签名**的，直接装不了，下一步你来签。

### 步骤 3：自签 + 安装
用你惯用的签名工具（爱思/全能签/巨魔/AltStore 等）给 `YuyuanBridge-unsigned.ipa`
签名并装到 iPad/iPhone。装好后主屏会有一个「芋圆机助手」图标。

### 步骤 4：首次授权 + 自测（关键验证）
1. 打开「芋圆机助手」，点 **请求「提醒事项」权限**、**请求「通知」权限**，弹窗都选"允许"。
2. 点 **① 立刻弹一条测试通知** → 退到桌面/锁屏，应能看到一条通知。
3. 点 **② 往提醒事项写一条测试** → 打开系统「提醒事项」App，应看到"带护照"。
4. 下方"处理日志"会记录每一步结果，出问题就是排错线索。

> 走到这一步说明**原生能力通了**。下面才轮到让芋圆机来触发它。

### 步骤 5：验证 `yuyuanji://` 链接（模拟芋圆机触发）
在「备忘录」里粘贴下面任意一条，点上去（备忘录里链接可点）：

- 弹通知：`yuyuanji://notify?title=测试&body=芋圆机通了`
- 写提醒：`yuyuanji://reminder?title=带护照&notes=陆言之：明早带上`
- 真实 JSON 形式（芋圆机将来用这种）：
  ```
  yuyuanji://action?b64=eyJ0eXBlIjogInJlbWluZGVyIiwgInRpdGxlIjogIuW4puaKpOeFpyIsICJtZXNzYWdlIjogIuaYjuaXqeiusOW+l+aKiuaKpOeFp+W4puS4iiIsICJ0aW1lIjogIjIwMjYtMDgtMjhUMDk6MDA6MDArMDg6MDAiLCAiY2hhcmFjdGVyIjogIumZhuiogOS5iyJ9
  ```
  （这条会在 2026-08-28 09:00 排一条"带护照"的提醒+通知）

点了能弹/能写 → **整条链路通了**，可以进下一步（把它接进 yuyuanTest.js）。

---

## 二、芋圆机（yuyuanTest.js）这边怎么发（下一步，先别急）

链路验证通过后，我会在 yuyuanTest.js 里加一个统一出口。核心就一小段——
把角色事件打成 JSON、base64、拼成 `yuyuanji://action?b64=...` 然后打开它：

```js
function iosAction(obj) {
  try {
    var json = JSON.stringify(obj);
    // 中文要先 encode 再转 base64，否则 btoa 会报错
    var b64 = btoa(unescape(encodeURIComponent(json)));
    var url = 'yuyuanji://action?b64=' + b64;
    // 打开这个链接 = 唤起"芋圆机助手"小 App
    window.top.location.href = url;   // 具体用哪种方式在脚本里再定
  } catch (e) { console.warn('iosAction 失败', e); }
}

// 例：角色发起一条提醒
iosAction({
  type: 'reminder',
  title: '带护照',
  message: '明早记得把护照带上',
  time: '2026-08-28T09:00:00+08:00',
  character: '陆言之'
});
```

> 注意：`yuyuanji://` 只能**手动触发/点一下**唤起（角色消息旁给个"设为提醒"按钮那种），
> **不能**在酒馆关着时后台自己发——那需要服务器，本版不做。

---

## 三、这版能做 / 不能做（别落差）

| 能 | 不能 |
|---|---|
| 你在用芋圆机时，点一下 → 写真·提醒事项 | 酒馆关着时，角色后台"突然找你"（要服务器） |
| 写好的提醒/通知到点原生弹（哪怕酒馆已关） | 网页无人操作时自动触发（要点一下唤起 App） |
| 通知进锁屏/通知中心 | —— |

**分发提醒**：未签名 .ipa 每个用户各自签；免费证书签的 7 天要重签，
长期用需 $99/年证书或巨魔等方案——这是 iOS 生态的坎，代码免不掉。

---

## 四、出错了怎么办
把**报错点**告诉我，我来改：
- Actions 编译红叉 → 复制那步的红色日志给我。
- 装上但点权限/自测没反应 → 看 App 里"处理日志"那几行。
- 点 `yuyuanji://` 没唤起 App → 多半是没装上或 scheme 没注册成功。
